﻿using System;

namespace firstProjectCs
{
	/// <summary>
	/// first gr
	/// </summary>
	class MainClass
	{
		/// <summary>
		/// The entry point of the program, where the program control starts and ends.
		/// </summary>
		/// <param name="args">The command-line arguments</param>
		public static void Main (string[] args)
		{
			int r;
			float j;

			Console.WriteLine ("first");
			r = int.Parse(Console.ReadLine());
			Console.WriteLine ("second");
			j = float.Parse(Console.ReadLine());
			Console.WriteLine (r*j);
		}
	}
}
